//
//  PhotoAblmu.swift
//  PhotoBrowser
//
//  Created by 朱子豪 on 16/4/12.
//  Copyright © 2016年 Space. All rights reserved.
//

import Foundation
import Photos
/**单个asset*/
class HAsset:NSObject{
    var asset:PHAsset
    var ID:String
    init(asset:PHAsset){
        self.asset = asset
        self.ID = asset.localIdentifier
    }
    
}

/**相册*/
class photoAblum {
    var ablumName:String?
    var imageCount:Int = 0
    var thumbImage:UIImage?
    var assets:[HAsset]?{
        didSet{
            imageCount = assets!.count
            guard assets?.count>0 else{return}
            PhotoUtil.sharedPhotoUtil.getImageFrom((assets?.last!.asset)!, mode: .Fast, quality:Quality.low, expectSize: CGSizeMake(60, 80)) { (image,_) -> () in
                self.thumbImage = image
            }
        }
    }
    subscript(index:Int) ->HAsset{
        return self.assets![index]
    }
}
/**整个手机的所相册*/
class phoneAblum {
    var ablumCount:Int!
    var ablumCollection:[photoAblum]?{
        didSet{
            ablumCount = ablumCollection?.count
        }
    }
    /**打印所有相册的名称*/
    static func printAllAblum()->(){
        let phone = PhotoUtil.sharedPhotoUtil.getPhonePhotoAblum()
        for one in phone.ablumCollection! {
            print("\(one.ablumName)")
        }
    }
    subscript(index:Int)->photoAblum?{
        return  self.ablumCollection![index]
    }
    subscript(ablumName:String)->photoAblum?{
        guard let _ = self.ablumCollection else{return nil}
        for  one in  self.ablumCollection!{
            if one.ablumName! == ablumName{
                return one
            }
        }
        return nil
    }
}
